﻿"Optical Circuit" (光回路 in Japanese)
Released at Tokyo Demo Fest 2015 PC 4K Intro (1st).


Description:

	optical_circuit.800x600.150221.exe
	-	At least nVidia GTX580,Radeon HD79xx.

	optical_circuit.1280x720.150221.exe (party version)
	-	For more faster GPUs.
	-	At least nVidia GTX780 for keeping 20fps.

	optical_circuit.1920x1080.150221.exe
	-	For future GPUs.


Credits:

	Code & Music : 0x4015


Special thanks:

	1k/4k demo framework
		http://www.iquilezles.org/

	Crinkler ver1.4
		http://www.crinkler.net/

