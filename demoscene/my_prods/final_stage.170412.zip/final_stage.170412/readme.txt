﻿"Final Stage"
"最終面" in Japanese.
Released at Revision Party 2017.


Description:

	final_stage.20170412.1280x720.exe (party version)
	-	file size 4092 bytes
	-	at least nVidia GTX980 for keeping 20fps.
	-	tested on Windows10.

	final_stage.20170412.1920x1080.exe
	-	file size 4093 bytes
	-	for more faster GPUs.
	-	tested on Windows10.

	Please wait several tens of seconds until start the demo.


Credits:

	Code, music and synth : 0x4015


Special thanks:

	1k/4k demo framework
		http://www.iquilezles.org/

	Crinkler ver2.0
		http://www.crinkler.net/

	Size coding articles in the pouet bbs

