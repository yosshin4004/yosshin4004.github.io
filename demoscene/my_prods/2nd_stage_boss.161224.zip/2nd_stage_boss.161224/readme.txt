﻿"2nd stage BOSS"
"二面ボス" in Japanese.
Released at Tokyo Demo Fest 2016.


Description:

	2nd_stage_boss.20160221.1280x720.win7.exe (party version)
	-	file size 4088 bytes
			shader for the graphics = 2486 bytes
			compute shader for the sound synthesizer = 841 bytes
			other = 761 bytes
	-	at least nVidia GTX780 for keeping 20fps.
	-	tested on Windows7.


	2nd_stage_boss.20160221.1920x1080.win7.exe
	-	for more faster GPUs.
	-	tested on Windows7.


	2nd_stage_boss.20161224.1280x720.win7_or_later.exe
	2nd_stage_boss.20161224.1920x1080.win7_or_later.exe
	-	safe version for future Windows versions.
		(more minified and built without Crinkler's /TINYIMPORT option.)
	-	tested on Windows10.


Credits:

	Code : 0x4015

	Music and synth : YET11


Special thanks:

	1k/4k demo framework
		http://www.iquilezles.org/

	Crinkler ver2.0
		http://www.crinkler.net/

	Size coding articles in the pouet bbs


