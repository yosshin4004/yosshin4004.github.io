Coacervate complex
Released at Tokyo Demo Fest 2013 PC Intro Compo



Description:

	coacervate_complex.800x600.130208.exe (party version)
		At least nVidia GTX580,Radeon HD79xx

	coacervate_complex.1280x720.130208.exe (party version)
	coacervate_complex.1280x720.200915.exe (final version)
	coacervate_complex.1920x1080.200915.exe (final version)
		For more faster GPUs


Credits:

	Code: 0x4015

	Music: Jaelyn Nisperos
		twitter: @chibitech
		http://m0e.me/1sx
		http://chibitech.nanjamonja.com/



Special thanks:

	1k/4k demo framework
		http://www.iquilezles.org/

	4Klang ver 3.0
		http://4klang.untergrund.net/

	Crinkler ver1.4
		http://www.crinkler.net/


