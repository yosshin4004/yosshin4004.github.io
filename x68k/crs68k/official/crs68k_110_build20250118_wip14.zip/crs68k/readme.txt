﻿===============================================================================
▽  超連射68k Ver.1.10 for Windows
===============================================================================

● 本ソフトウェアの説明

    超連射68k は、90年代上半期テイストな縦スクロール STG です。
    元々 X68K 用同人ソフトとして 1995～1997年にかけて開発されたものをそのまま
    Windows 向けに移植しました。

    超連射68k はこれまで、1997年冬のコミケでリリースされた ver1.0x が最終版と
    なっていました。コミケでのリリース終了後、ver1.0x ベースの Windows 移植版
    がリリースされました。その後も X68k 版に対してのみ細かい更新が行われていま
    したがリリースには至っておらず、最新のソースとデータが散逸した状態になって
    いました。
    2021年頃からサルベージ作業を進めた結果、幸い必要なファイルは救済することが
    できましたので、このたび ver1.10 としてリリースすることにいたしました。

    本バージョンでは、一部のサウンドデータおよびグラフィクスデータが ver1.0x
    と異なっています。ゲーム本編の内容は ver1.0x から変更はないため、リプレイ
    データレベルで互換性があります。


● 推奨動作環境

    Windows10 以降
    DrectX12 以降


● 注意事項

    本ソフトウェアは無保証です。


● 起動方法

    インストーラは存在しません。
    cho_ren_sha_68k.exe を実行してください。


● 操作方法

    ・ゲーム実行時
        ・自機の移動
            ジョイスティック
            カーソルキー
            テンキー

        ・ショット発射
            ジョイスティック の トリガ A
            キーボードの左 CTRL キー、または Z キー

        ・ボンバー発射
            ジョイスティック の トリガ B
            キーボードの左 SHIFT キー、または X キー

        ・一時停止
            ジョイスティック の START ボタン
            キーボードの PageUp

       ・強制ゲームオーバー
           ジョイスティック の START SELECT 同時長押し
           キーボードの PageUp PageDown 同時長押し

    ・リプレイ再生時
        ・フレームスキップ速度設定（リプレイ再生時のみ利用可能）
            キーボードの [1]～[9]

    ・リプレイユーティリティ
        ・リプレイデータの一覧表示開始順位の変更
            ジョイスティック・カーソルキー・テンキーの左右

    ・ゲームの終了
        ESC キー


● リプレイデータについて

    フォルダ rep_dat 以下にある *.rep ファイルがリプレイデータファイルです。
    このファイルをやり取りすることで、ユーザー間でリプレイデータを交換可能
    です。

    ※  ver 1.0x 以前の古いリプレイデータは、etc_dat/demo.rep に上書きする
        ことで、タイトル画面から自動実行されるデモプレイとして閲覧できます。
        古いリプレイデータを rep_dat 以下にコピーしても認識されません。


● トラブルシューティング

    ・「発行元を確認できませんでした」というセキュリティ警告が表示される
        超連射68k の実行ファイルはデジタル署名を持たないので、このような警告が
        出てしまいます。（デジタル署名を取得すれば解消するのですが、年間数万円
        の維持費用が必要になってしまうため、取得は行っていません。）
        セキュリティ警告が表示されても、アーカイブファイルの sha256sum が公式
        ダウンロード URL に記載されているものと一致していれば安全です。

    ・「エントリポイントが見つかりません」というメッセージが表示される
        Windows10 未満の環境で実行している可能性があります。

    ・ティアリングが発生する
        NVIDIA コントロールパネルなどの GPU 設定ツールで垂直同期がオフに設定
        されている可能性があります。

    ・表示先モニタを選択したい
        [Win] + [Shift] + ←→ キーで、ウィンドウを表示するディスプレイが選択
        可能です。

    ・ジョイスティックまたはゲームパッドのボタンアサインが正しくない
        DirectInput 世代の古い機器では、機種ごとにボタンアサインが異なって
        います。このような場合、キーボード操作でタイトル画面から CONFIGURE
        メニューに入り、ASSIGN JOYSTICK BUTTONS を実行することで修復可能です。


● ゲーム動作不良に関するお問い合わせ

    もし、上記のトラブルシューティングに該当しない問題に遭遇した場合は、
        yosshin4004@gmail.com よっしん
    まで、下記の内容を添えてご連絡頂けますと幸いです。

    --------------------------------------------------------------------------
        1. 問題の詳細
            発生する現象：
            （例：起動しない、操作できないなど）
            問題の発生タイミング：
            （例：起動時、起動後、特定の操作を行った時など）
            発生頻度：
            （例：毎回、時々など）

        2. エラーメッセージ（表示された場合のみ）
            エラーメッセージ内容：

        3. 追加情報
            その他、問題の解決に役立ちそうな情報や状況：
            （例：UMPC などの特殊な環境、特殊なデバイスが接続されているなど）

        4. 添付ファイル
            ゲーム起動後、カレントディレクトリに app_log.txt というファイルが
            生成されます。このファイルには、ゲームの動作ログに加え、CPU や GPU
            を含むお使いのシステムのスペック情報が記録されています。
            これらの情報のご提供にご同意いただける場合は、添付ファイルとして
            ご送付ください。
    --------------------------------------------------------------------------


● お問い合わせ

	yosshin4004@gmail.com よっしん

    ※  すぐに返答できない場合があります。ご了承ください。


● 謝辞

    超連射68k Ver.1.10 for Windows は以下のソフトウェアを利用しています。

    ・Ogg / Vorbis
        https://xiph.org/vorbis/
        Copyright (c) 2002-2020 Xiph.org Foundation

        Redistribution and use in source and binary forms, with or without
        modification, are permitted provided that the following conditions
        are met:

        - Redistributions of source code must retain the above copyright
        notice, this list of conditions and the following disclaimer.

        - Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.

        - Neither the name of the Xiph.org Foundation nor the names of its
        contributors may be used to endorse or promote products derived from
        this software without specific prior written permission.

        THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
        ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
        LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
        A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE FOUNDATION
        OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
        SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
        LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
        DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
        THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
        (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
        OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

    ・Portable mdx decoder
        https://github.com/yosshin4004/portable_mdx

        X68k MXDRV music driver version 2.06+17 Rel.X5-S
        	(c)1988-92 milk.,K.MAEKAWA, Missy.M, Yatsube

        Converted for Win32 [MXDRVg] V2.00a
        	Copyright (C) 2000-2002 GORRY.

        X68Sound_src020615
        	Copyright (C) m_puusan.

        Ported for 64bit environments
        	Copyright (C) 2018 Yosshin.


● 更新履歴

    2025/01/15
        ・スペースを含むデフォルトスコア名が次回起動時に復元されない問題を修正
        ・CONFIGURE に音量調節機能を追加
        ・[Win] + [Shift] + ←→ キーで表示先ディスプレイを選択可能にした
        ・VSYNC が採れない環境でも 60Hz を維持できるように修正
        ・キーアサインのアナログスティック対応を改善
        ・フレームスキップ機能をキーボードの [F1]～[F12] から [1]～[9] に変更
        ・古い Intel CPU 内蔵 GPU がランタイムエラーを起こす問題を修正
        ・Intel CPU 内蔵 GPU では低遅延よりも FPS 安定性を優先するように修正
        ・エラー終了時に詳細な動作ログを保存するように修正

    2025/01/01
        ・Ver.1.10 X68000 版からサルベージされたアセットを取り込み
        ・キーアサイン変更機能の追加
        ・Ogg / Vorbis 形式の BGM 再生に対応
        ・MDX 再生ドライバを Portable mdx decoder に変更
        ・タイトル画面に REPLAY メニューを追加
        ・リプレイデータの保存形式を変更
        ・リプレイデータを複数保存できるように変更
        ・CONFIG を全面的にブラッシュアップ
        ・終了時に CONFIG 設定を保存するように変更
        ・フレームスキップ機能（キーボードの [F1] ～ [F12]）を導入
        ・強制ゲームオーバー手順を START SELECT 長押しに変更（暴発回避のため）
        ・ゲーム中にスクリーンセーバーが起動しないように修正
        ・スコアネーム入力がキーボード対応になった
        ・オート連射機能を追加（CONFIG で有効化できる）
        ・クレジット表記画面を追加

    2017/05/23
        ・マルチコア環境でサウンドが壊れる問題を修正

    2005/08/20
        ・mxdrv.dll / X68Sound.dll の更新
        ・デスクトップのウィンドウ位置・サイズの復元に失敗するバグの修正
        ・CONFIG モードからスコア初期化機能を削除
        ・ドキュメント内の URL およびメールアドレス修正

    2001/09/12
        ・DirectDrawSurface の世代を一つ下げた
        ・DirectSound のプライマリバッファが使用出来ない環境では
          セカンダリバッファを使うようにした
        ・マルチメディアタイマーの安定性向上
        ・サーフェスが復元できないバグを修正
        ・5面 6面 の BGM が、X68K 版と逆になっていたので訂正
        ・フレームレート調整機能を、F G H J キーに割り当てた

    2001/08/22
        ・バグ調査用に APP_LOG.TXT を生成するようにした
        ・最適化コンパイルが OFF になっていたらしいので修正

    2001/08/08
        ・Windows 版の完成バージョン公開


